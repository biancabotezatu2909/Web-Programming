import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import NthDegreeRelations from './NthDegreeRelations';

const Home: React.FC = () => {
    const [degree, setDegree] = useState<number>(0);
    const playerId = 1; // Assuming the logged-in player ID is stored here
    const navigate = useNavigate();

    const handleSearchClick = () => {
        navigate('/search');
    };

    return (
        <div>
            <h1>Main Page</h1>
            <button onClick={handleSearchClick}>Search</button>
            <div>
                <label>
                    Enter Degree:
                    <input type="number" value={degree} onChange={(e) => setDegree(parseInt(e.target.value) || 1)} min="1" />
                </label>
                <NthDegreeRelations playerId={playerId} degree={degree} />
            </div>
            {/* Other functionalities can be added here */}
        </div>
    );
};

export default Home;
