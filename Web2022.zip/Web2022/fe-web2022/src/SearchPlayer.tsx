import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Player {
    ID: number;
    name: string;
    position: string;
}

const SearchPlayer: React.FC = () => {
    const [query, setQuery] = useState<string>('');
    const [results, setResults] = useState<Player[]>([]);

    useEffect(() => {
        const fetchPlayers = async () => {
            if (query.length > 0) {
                try {
                    const response = await axios.get(`http://localhost/Web2022/be-web2022/search.php?query=${query}`);
                    setResults(response.data);
                } catch (error) {
                    console.error("There was an error fetching the data!", error);
                }
            } else {
                setResults([]);
            }
        };

        fetchPlayers();
    }, [query]);

    return (
        <div>
            <h2>Search Players</h2>
            <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by player name"
            />
            <ul>
                {results.map(player => (
                    <li key={player.ID}>{player.name} - {player.position}</li>
                ))}
            </ul>
        </div>
    );
};

export default SearchPlayer;
