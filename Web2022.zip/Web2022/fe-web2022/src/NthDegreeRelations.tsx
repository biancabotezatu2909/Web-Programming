import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Player {
    ID: number;
    name: string;
    position: string;
}

interface Props {
    playerId: number;
    degree: number;
}

const NthDegreeRelations: React.FC<Props> = ({ playerId, degree }) => {
    const [relations, setRelations] = useState<Player[]>([]);

    useEffect(() => {
        const fetchRelations = async () => {
            try {
                const response = await axios.post('http://localhost/Web2022/be-web2022/nthDegreeRelations.php', {
                    playerId: playerId,
                    degree: degree
                });
                const relationIds = response.data;

                const playerPromises = relationIds.map((id: number) =>
                    axios.get(`http://localhost/Web2022/be-web2022/player.php?id=${id}`)
                );
                const playerResponses = await Promise.all(playerPromises);
                const players = playerResponses.map(res => res.data);

                setRelations(players);
            } catch (error) {
                console.error("There was an error fetching the relations!", error);
            }
        };

        fetchRelations();
    }, [playerId, degree]);

    return (
        <div>
            <h2>{degree}-degree Relations</h2>
            <ul>
                {relations.map(player => (
                    <li key={player.ID}>{player.name} - {player.position}</li>
                ))}
            </ul>
        </div>
    );
};

export default NthDegreeRelations;
