<?php

include 'dbcon.php';

$playerId = $_GET['id'] ?? null;

if ($playerId !== null) {
    $stmt = $conn->prepare("SELECT * FROM Player WHERE ID = ?");
    $stmt->bind_param("i", $playerId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode([]);
    }

    $stmt->close();
} else {
    echo json_encode([]);
}

$conn->close();
?>
