<?php

include 'dbcon.php';

function getNthDegreeRelations($conn, $playerId, $degree) {
    $relations = [];
    $currentLevel = [$playerId];
    $visited = [$playerId];

    for ($i = 0; $i < $degree; $i++) {
        $nextLevel = [];
        foreach ($currentLevel as $id) {
            $stmt = $conn->prepare("SELECT IDplayer2 FROM TeamMembers WHERE IDplayer = ? UNION SELECT IDplayer FROM TeamMembers WHERE IDplayer2 = ?");
            $stmt->bind_param("ii", $id, $id);
            $stmt->execute();
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                if (!in_array($row['IDplayer2'], $visited)) {
                    $nextLevel[] = $row['IDplayer2'];
                    $visited[] = $row['IDplayer2'];
                }
            }

            $stmt->close();
        }
        $relations = array_merge($relations, $nextLevel);
        $currentLevel = $nextLevel;
    }

    return $relations;
}

$input = json_decode(file_get_contents("php://input"), true);
$playerId = $input['playerId'] ?? null;
$degree = $input['degree'] ?? 1;

if ($playerId !== null && $degree > 0) {
    $relations = getNthDegreeRelations($conn, $playerId, $degree);
    echo json_encode($relations);
} else {
    echo json_encode([]);
}

$conn->close();
?>
