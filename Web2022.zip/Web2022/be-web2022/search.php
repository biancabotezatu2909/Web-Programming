<?php

include 'dbcon.php';

$query = $_GET['query'] ?? '';

if ($query) {
    $stmt = $conn->prepare("SELECT * FROM Player WHERE name LIKE ? ORDER BY name ASC");
    $likeQuery = "%".$query."%";
    $stmt->bind_param("s", $likeQuery);
    $stmt->execute();
    $result = $stmt->get_result();

    $players = [];
    while ($row = $result->fetch_assoc()) {
        $players[] = $row;
    }

    echo json_encode($players);
    $stmt->close();
} else {
    echo json_encode([]);
}

$conn->close();
?>
