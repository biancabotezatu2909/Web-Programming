<?php

include 'dbcon.php';

session_start();

$input = json_decode(file_get_contents("php://input"), true);
$username = $input['username'] ?? null;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $username) {
    $stmt = $conn->prepare("SELECT * FROM Player WHERE name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['ID'];
        $_SESSION['username'] = $user['name'];
        echo json_encode(["message" => "Login successful.", "user" => $_SESSION['username']]);
    } else {
        echo json_encode(["message" => "Invalid username."]);
    }

    $stmt->close();
} else {
    echo json_encode(["message" => "Please provide a username."]);
}

$conn->close();
?>
