﻿using System.ComponentModel.DataAnnotations;

namespace ConcertReservations.Models
{
    public class TravelForm
    {
        [Required]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Travel Date")]
        public DateTime TravelDate { get; set; }

        [Required]
        [Display(Name = "Destination City")]
        public string DestinationCity { get; set; }
    }
}
