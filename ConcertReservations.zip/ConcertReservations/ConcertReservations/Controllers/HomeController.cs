using ConcertReservations.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ConcertReservations.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext dbContext;

        public HomeController(ILogger<HomeController> logger, AppDbContext dbContext)
        {
            _logger = logger;
            this.dbContext = dbContext;
        }

        public IActionResult Index()
        {
            return View();
        }

        public ActionResult FlightsList()
        {
            string dateString = HttpContext.Session.GetString("Date");
            string destinationCity = HttpContext.Session.GetString("DestinationCity");

            // Parse the date string to DateTime
            if (!DateTime.TryParse(dateString, out DateTime date))
            {
                return BadRequest("Invalid date format.");
            }

            // Query hotels using DateTime comparison
            var flights = dbContext.Flights
                                  .Where(f => f.Date.Date == date.Date &&
                                              f.DestinationCity == destinationCity &&
                                              f.AvailableSeats > 0)
                                  .ToList();
            return View(flights);
        }

        public IActionResult CreateFlightReservation(int flightId)
        {
            Reservation reservation = new Reservation();
            reservation.IdReservedResource = flightId;
            reservation.Type = "Flight";
            reservation.Person = HttpContext.Session.GetString("Person");
            dbContext.Reservations.Add(reservation);
            dbContext.SaveChanges();

            Flight flight = dbContext.Flights.Find(flightId);
            flight.AvailableSeats = flight.AvailableSeats - 1;
            dbContext.Flights.Update(flight);
            dbContext.SaveChanges();

            return RedirectToAction("FlightsList");
        }

        public ActionResult HotelsList()
        {
            string dateString = HttpContext.Session.GetString("Date");
            string destinationCity = HttpContext.Session.GetString("DestinationCity");

            // Parse the date string to DateTime
            if (!DateTime.TryParse(dateString, out DateTime date))
            {
                return BadRequest("Invalid date format.");
            }

            // Query hotels using DateTime comparison
            var hotels = dbContext.Hotels
                                  .Where(h => h.Date.Date == date.Date &&
                                              h.City == destinationCity &&
                                              h.AvailableRooms > 0)
                                  .ToList();

            return View(hotels);
        }
        public IActionResult CreateHotelReservation(int hotelId)
        {
            Reservation reservation = new Reservation();
            reservation.IdReservedResource = hotelId;
            reservation.Type = "Hotel";
            reservation.Person = HttpContext.Session.GetString("Person");
            dbContext.Reservations.Add(reservation);
            dbContext.SaveChanges();

            Hotel hotel = dbContext.Hotels.Find(hotelId);
            hotel.AvailableRooms = hotel.AvailableRooms - 1;
            dbContext.Hotels.Update(hotel);
            dbContext.SaveChanges();

            return RedirectToAction("HotelsList");
        }

     
        public IActionResult Choose()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Submit(TravelForm model)
        {
            if (ModelState.IsValid)
            {
                HttpContext.Session.SetString("Person", model.Name);
                HttpContext.Session.SetString("DestinationCity", model.DestinationCity);
                HttpContext.Session.SetString("Date", model.TravelDate.Date.ToString());
                return RedirectToAction("Choose");
            }

            return View("Index", model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
