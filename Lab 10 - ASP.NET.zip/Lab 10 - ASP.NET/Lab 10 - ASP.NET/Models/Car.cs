﻿using System.ComponentModel.DataAnnotations;

namespace CarsApp.Models
{
    public class Car
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string Model { get; set;}
        [Required]
        public string EnginePower { get; set; }
        [Required]
        public string Fuel { get; set; }
        [Required]
        public int Price { get; set; }
        [Required]
        public string Color { get; set; }
        [Required]
        public int Age { get; set; }
        [Required]
        public string History { get; set; }
    }
}
