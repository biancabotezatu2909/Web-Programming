﻿namespace SoftwareWeb.Models
{
    public class SoftwareDeveloper
    {
        //id(int), name(string), age(int), skills(string)

        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Skills { get; set; }
    }
}
