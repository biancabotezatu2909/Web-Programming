﻿namespace SoftwareWeb.Models
{
    public class Project
    {
        //id(int), ProjectManagerID(int), name(string), description
        //(string),   members(string)

        public int Id { get; set; }

        public int ProjectManagerID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Members { get; set; }
    }
}
