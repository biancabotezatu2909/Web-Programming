﻿using Microsoft.EntityFrameworkCore;
using SoftwareWeb.Models;

namespace SoftwareWeb.Database
{
    public class AppDbContext : DbContext
    {
        public DbSet<SoftwareDeveloper> SoftwareDevelopers { get; set; }
        public DbSet<Project> Projects { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }
}
