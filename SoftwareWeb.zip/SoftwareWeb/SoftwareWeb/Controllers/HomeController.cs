using Microsoft.AspNetCore.Mvc;
using SoftwareWeb.Database;
using SoftwareWeb.Models;
using System.Diagnostics;

namespace SoftwareWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _appDbContext;

        public HomeController(ILogger<HomeController> logger, AppDbContext dbContext)
        {
            _logger = logger;
            _appDbContext = dbContext;

        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpPost]
        public IActionResult SetUser(string userName)
        {
            HttpContext.Session.SetString("userName", userName);
            return RedirectToAction("AllProjects","Home");
        }

        public IActionResult AllProjects()
        {
            return View(_appDbContext.Projects.ToList());
        }
        public IActionResult MyProjects()
        {
            string userName = HttpContext.Session.GetString("userName");
            return View(_appDbContext.Projects.Where(p => p.Members.Contains(userName)).ToList());
        }
    }

}
